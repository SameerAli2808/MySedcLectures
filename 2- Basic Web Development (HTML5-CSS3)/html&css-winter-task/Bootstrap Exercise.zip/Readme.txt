Recreate this layout using the Bootstrap Framework (you can include it however you want).
Please add your own images and you can add your own text and headings.
Use Open Sans Font, you can find it on Google Fonts.
The site also MUST be responsive.

* The idea for this exercise is for you to have a portfolio site for yourself, thats why you need to add your own content.

The deadline for this exercise is 10.01.2019.

Happy Holidays!